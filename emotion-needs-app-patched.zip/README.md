# Emotion → Unmet Needs Explorer

## One-click deploy (Option A)
1) Push this folder to a new GitHub repo.
2) In Netlify: **Add new site → Import from Git** → pick your repo.
3) Accept defaults (build: `npm run build`, publish: `dist`) → **Deploy**.
4) Netlify gives you a URL like `https://your-site-name.netlify.app`.

## Local dev (optional)
```bash
npm i
npm run dev
```
